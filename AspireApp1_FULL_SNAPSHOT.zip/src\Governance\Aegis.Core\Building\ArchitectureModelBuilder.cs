﻿namespace Aegis.Core.Building;
