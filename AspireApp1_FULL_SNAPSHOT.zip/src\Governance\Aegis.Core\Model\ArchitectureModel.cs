﻿namespace Aegis.Core.Model;
