﻿namespace Ums.Cli.Adapters;
