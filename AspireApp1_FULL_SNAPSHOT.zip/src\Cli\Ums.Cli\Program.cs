﻿// UMS CLI entry point
Console.WriteLine("UMS CLI v1.0");
