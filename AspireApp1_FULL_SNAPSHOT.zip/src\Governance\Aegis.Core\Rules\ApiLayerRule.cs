﻿namespace Aegis.Core.Rules;
