﻿namespace Aegis.Core.Config;
