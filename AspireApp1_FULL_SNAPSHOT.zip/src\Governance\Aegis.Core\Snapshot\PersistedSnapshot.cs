﻿namespace Aegis.Core.Snapshot;
